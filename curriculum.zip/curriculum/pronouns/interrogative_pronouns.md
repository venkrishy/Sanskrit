### Interrogatives

|           |  |
| :-------- | :- |
| कः (Kah)  | Who (masculine) |
| का (Kā)  | Who (feminine) |
| किम् (Kim) | What  |