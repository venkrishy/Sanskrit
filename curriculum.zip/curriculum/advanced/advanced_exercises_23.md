1. स: शालां गच्छति, पाठं पठति | Saḥ śālāṁ gacchati, pāṭhaṁ paṭhati.
   स: शालां गत्वा पाठं पठति | Saḥ śālāṁ gatvā pāṭhaṁ paṭhati.
   ते कार्यं कुर्वन्ति, श्रान्ताः भवन्ति | Te kāryaṁ kurvanti, śrāntāḥ bhavanti.

   Devanagari: स: शालां गच्छति, पाठं पठति | स: शालां गत्वा पाठं पठति | ते कार्यं कुर्वन्ति, श्रान्ताः भवन्ति |
   Transliteration: Saḥ śālāṁ gacchati, pāṭhaṁ paṭhati. | Saḥ śālāṁ gatvā pāṭhaṁ paṭhati. | Te kāryaṁ kurvanti, śrāntāḥ bhavanti. 
   Translation: He goes to school, reads the lesson. | Having gone to school, he reads the lesson. | They do the work, they become tired.

2. ते कार्यं कुर्वन्ति, श्रान्ताः ....... | 
   ................................... |
   Possible Answer: भवन्ति (bhavanti) - they become

3. शिशुः क्रीडङ्गने पतति, रोदनं करोति | Śiśuḥ krīḍaṅgane patati, rodanaṁ karoti. 
   ................................... |
   Translation: The child falls in the playground, cries.

4. अहं फलं खादितवान्, जलं पीतवान् | Ahaṁ phalaṁ khāditavān, jalaṁ pītavān.
   ................................... |
   Translation: I ate fruit, drank water.

5. किञ्चित् पानीयं पिबतु, अनन्तरं गच्छतु | Kiñcit pānīyaṁ pibatu, anantaraṁ gacchatu. 
   ................................... |
   Translation: Drink some water, go afterwards.

6. स: पत्रं लिखितवती, प्रेषितवती | Sa patraṁ likhitavatī, preṣitavatī.
   ................................... |
   Translation: She wrote a letter, sent it.

7. भवन्तः वार्तां शृण्वन्ति | विषयं जानन्ति | Bhavantaḥ vārtāṁ śṛṇvanti. Viṣayaṁ jānanti. 
   ................................... |
   Translation: You all listen to the news. Know the subject matter.

8. वयं नाटकं पश्यामः | गृहं आगच्छामः | Vayaṁ nāṭakaṁ paśyāmaḥ. Gṛhaṁ āgacchāmaḥ.
   Translation: We watch a play. We come home.

9. ताः बालिकाः विषयं स्मरन्ति, सम्यक् लिखन्ति | Tāḥ bālikāḥ viṣayaṁ smaranti, samyak likhanti.  
   ................................... |
   Translation: Those girls remember the subject, write properly.

The image also contains a list of verb forms and their grammatical terms in Sanskrit at the bottom.