Here is the translation and explanation of the Sanskrit language exercise in the image:

Devanagari Script / English Transliteration / English Translation

पिबति / Pibati / Pitṛ
ददाति / Dadāti / Janātṛ
शृणोति / Śrṇoti / Likhati
मिलति / Milati / Mātṛ

पास्यति / Pāsyati / Dāsyati
जास्यति / Jāsyati / Śrosyati
लेक्षिष्यति / Lekhiṣyati / Meliṣyati

पृच्छति / Pṛcchati / Tyajati
शक्नोति / Śaknoti / Upaviśati
उत्तिष्ठति / Uttiṣṭhati / Gṛhṇāti

प्रक्ष्यति / Prakṣyati / Tyakṣyati
शक्ष्यति / Śakṣyati / उपवेक्ष्यति / Upavekṣyati
उत्थास्यति / Utthāsyati / ग्रहीष्यति / Grahīṣyati

13.1  सम्बोधनरूपाणि / Sambodhanarūpāṇi

राम: कृष्ण: गोविन्द: गौरी मित्रम् - इत्यादीनां सर्वेषां शब्दानां सम्बोधनरूपाणि भिन्नानि भवन्ति। / 
Rāmah, Kṛṣṇah, Govindah, Gaurī, mitram - ityādīnāṁ sarveṣāṁ śabdānāṁ sambodhanarūpāṇi bhinnāni bhavanti.

(The vocative forms of all the words like Rāma, Kṛṣṇa, Govinda, Gaurī, mitra are different.)

राम: / Rāmah / राम | / Rāma ! / सीता / Sītā / सीते | / Sīte !
कृष्ण: / Kṛṣṇah / कृष्ण | / Kṛṣṇa ! / रमा / Ramā / रमे | / Rame ! 
गोविन्द: / Govindah / गोविन्द | / Govinda ! / मान्या / Mānyā / मान्ये | / Mānye !
हरि: / Harih / हरे | / Hare ! / गौरी / Gaurī / गौरि | / Gauri !
गुरु: / Guruh / गुरो | / Guro ! / भगिनी / Bhaginī / भगिनि | / Bhagini !
राजा / Rājā / राजन् | / Rājan ! / लक्ष्मी: / Lakṣmīḥ / लक्ष्मि | / Lakṣmi !   
महाराज: / Mahārājah / महाराज | / Mahārāja ! / अम्बा / Ambā / अम्ब | / Amba !
महोदय: / Mahodayah / महोदय | / Mahodaya ! / माता / Mātā / मात: | / Mātaḥ ! 
पिता / Pitā / पित: | / Pitaḥ !