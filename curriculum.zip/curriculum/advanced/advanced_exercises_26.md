Here is the translation and explanation of the Sanskrit language exercise shown in the image:

27.1
एतानि वाक्यानि शुद्धानि करोतु। - Etāni vākyni śuddhāni karotu.
Asuddhaanivaakyaani suddhaani karotu.  
Meaning: Make these sentences pure/correct.

यथा - gudaasya ruchi: काडुः । ✖
Na, gudaasya rucih madhuraH.
न, गुदस्य रुचि: मधुरः। - Na, gudasya ruciH madhuraH. 
Maricikayaahruchih madhurah.

१. मरीचिकाया: रुचि: मधुरः। -- 
......................................... ।
Aamraphalasya rucih tiktah.
आम्रफलस्य रुचिः तिक्तः। - Āmraphalasya ruciḥ tiktaḥ. 
........................................ ।

२. आवालेस्य रुचिः मधुरः।
........................................ ।
Avalchaasya rucih madhuraH.

३. अवलेहस्य रुचि: मधुरः। --
........................................ ।
Tintrinyanrucih katuh.
तिन्त्रिण्यां रुचिः कटुः। - Tintriṇyāṃ ruciḥ kaṭuḥ.
......................................... ।

४. तिन्त्रिण्याः रुचिः कटुः । --
........................................ ।

27.2  
एतत् सम्भाषण पठतु - Etat sambhāṣaṇa paṭhatu.

पुत्रः - अम्ब ! किम् अद्य क्वथितं बहु कष्टं अस्ति ! 
Putrah - Amba ! kim adya kvathitam bahu kaṣṭaṃ asti !

माता - तहि स्वथितं मा स्वीकरोतु | तक्रं परिवेषयामि ।
Mātā - Tarhi kvathitam mā svīkarotu. Takram pariveṣayāmi.

पुत्रः - तक्रं बहु आम्लम् अस्ति अम्ब ! Takram bahu aamlam asti amba !

माता - भवांतु केवलम् मधुरम् इच्छति । एतत् मोदकं खादतु । बहु मधुरम् अस्ति ।  
Bhavāntu kevalam madhuram icchati. Etat modakam khādātu. bahu madhuram asti.

पुत्रः - सत्यम् अम्ब ! एतत् मधुरम् अस्ति । Satyam amba ! Etat madhuram asti.

माता - कारवेल्लस्य व्यञ्जनम् अस्ति । किंचित् परिवेषयामि वा ?
Kāravellasya vyañjanam asti. Kiñcit pariveṣayāmi vā ?

पुत्रः - मास्तु अम्ब, कारवेल्लं तिक्तं भवति । अहं तिक्तं न इच्छामि । किंचित् लवनं परिवेषयतु ।  
Māstu amba, kāravellam tiktaṃ bhavati. Ahaṃ tiktam na icchāmi. Kiñcit lavaṇaṃ pariveṣayatu. 

माता - स्वीकरो