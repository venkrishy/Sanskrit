Here is the translation and explanation of the Sanskrit language exercise in the provided image:

सह Saha
स: पुत्रेण सह आपणं गच्छति ।
Sah putreṇa saha āpaṇaṁ gacchati.
He goes to the market with his son.

सा सख्या सह विद्यालयं गच्छति ।
Sā sakhyā saha vidyālayaṁ gacchati.
She goes to school with her friend.

उदाहरणं दृष्ट्वा तद्रूशवाक्यानि लिखत् - Udāharaṇaṁ dṛṣṭvā tādṛśavākyāni likhatu.
Write similar sentences based on the example. - Rāmah/Rāvaṇah ..... yuddham kṛtavān.

१. राम: / रावण: ......... युद्धं कृतवान् | Rāmah/Rāvaṇena saha yuddhaṁ kṛtavān.
Ram: Rāvaṇena saha yuddhaṁ kṛtavān | Rāmah/Rāvaṇah ..... yanam gatavān. 

२. लक्ष्मण: / राम: ........ वनं गतवान् | Lakṣmaṇah/ Rāmah ..... vanam gatavān.
Lakshman: Lakṣmaṇah/Rāmah ..... vanam gatavān | ...............................................।

..................................... अभ्यासं करोति । Gopālah/ Mādhavah ..... abhyāsaṁ
३. गोपाल: / माधव: ........ kṛtavān.
Gopal: Gopālah/Mādhavah ..... abhyāsaṁ karoti | ...............................................।
..................................................... | ...............................................।

४. आहं / मित्रम् ......... नाटकं पश्यामि | Ahaṁ/ mitram ..... nāṭakaṁ paśyāmi.
Ah: Ahaṁ/ mitram ..... nāṭakaṁ paśyāmi | ...............................................।

५. एषा / सीता .......... तिष्ठति | Eṣā/ Sītā ..... tiṣṭhati.
Esha: Eṣā/Sītā ..... tiṣṭhati | ...............................................।

............ सम्भाषणं करोति । Sureśah/ bhaginī ..... saṁbhāṣaṇar
६. सुरेश: / भगिनी .......... karoti.
Suresh: Sureśah/ bhaginī ..... saṁ bhāṣaṇaṁ karoti | ...............................................।
...................................................... | ...............................................।

७. माता / पुत्री ......... कार्यं करोति । Mātā/ Putrī .... kāryaṁ karoti.
Mata: Mātā/ Putrī .... kāryaṁ karoti | ...............................................।

८. अध्यापक: / छात्रा: ........... प्रवासार्थं गतवान् । Adhyāpakah / Chātrāh ... pravāsārthaṁ gatavān.
Adhyapak: Adhyāpakah/Chātrāh ... pravāsārthaṁ gatavān | ...............................................।

९. लता / सख्य: ------ क्रीडति । Latā/ Sakhyah .... krīḍati.
Lata: Latā/ Sakhyah .... krīḍati | ...............................................।