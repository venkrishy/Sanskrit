Numbers (सङ्ख्याः - Sankhyāh)
एकम् (Ekam) - 1

द्वे (Dve) - 2

त्रीणि (Trīṇi) - 3

चत्वारि (Catvāri) - 4

पञ्च (Pañca) - 5

षट् (Ṣaṭ) - 6

सप्त (Sapta) - 7

अष्ट (Aṣṭa) - 8

नव (Nava) - 9

दश (Daśa) - 10
