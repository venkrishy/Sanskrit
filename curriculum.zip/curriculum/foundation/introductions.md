## 1.1 Introduction and Names   

*मम नाम सुरेशःMama nāma Sureśaḥ.*
Translation: My name is Suresh.

*भवतः नाम किम् ?Bhavatah nama kim?*
Translation: What is your name? (to a male)

*मम नाम रामः ।Mama nāma Rāmaḥ.*
Translation: My name is Rama.

*मम नाम सुरेशःMama nāma Sureśaḥ.*
Translation: My name is Suresh.

*भवत्याः नाम किम् ?Bhavatyāḥ nāma kim?*
Translation: What is your name? (to a female)

*मम नाम लता ।Mama nāma Latā.*
Translation: My name is Lata.

*भवतः नाम किम् ?Bhavatah nama kim ?*
Translation: What is your name? (to a male)

*मम नाम कृष्णः ।Mama nāma Kṛṣṇaḥ.*
Translation: My name is Krishna.

*भवत्याः नाम किम् ?Bhavatyāḥ nāma kim ?*
Translation: What is your name? (to a female)

*मम नाम राधा ।Mama nāma Rādhā.*
Translation: My name is Radha.

*एतस्य उत्तरं लिखतु - Etasya uttaram likhatu*
Translation: Write the answer to this.

*भवतः नाम किम् ? Bhavataḥ nāma kim ?*
Translation: What is your name? (to a male)

*भवत्याः नाम किम् ? Bhavatyāḥ nāma kim ?*
Translation: What is your name? (to a female)
