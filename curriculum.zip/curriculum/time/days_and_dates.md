Here is the translation and explanation of the Sanskrit language exercise in the image:

अत्र रिक्तानि स्थलानि पूरयतु - Atra riktāni sthalāni pūrayatu
English Translation: Here fill in the blank spaces.

अद्य भानुवासरः - Adya bhānuvāsaraḥ
English Translation: Today is Sunday.

शनिवासरः - Śanivāsaraḥ
English Translation: Saturday

सोमवासरः - Somavāsaraḥ
English Translation: Monday

शुक्रवासरः - Śukravāsaraḥ
English Translation: Friday

मङ्गलवासरः - Maṅgalavāsaraḥ
English Translation: Tuesday

अद्य मङ्गलवासरः | - Adya maṅgalavāsaraḥ |
English Translation: Today is Tuesday.

श्वः बुधवासरः | - Śvaḥ budhavāsaraḥ |
English Translation: Tomorrow is Wednesday.

प्रथमवाक्यं पठित्वा प्रश्नस्य उत्तरं लिखतु - Prathamavākyaṁ paṭhitvā praśnasya uttaraṁ likhatu
English Translation: Read the first sentence and write the answer to the question.

प्रश्न - 1. अद्य सोडशदिनाङ्कः |
Praśna - 1. Adya soḍaśadināṅkaḥ |
English Translation: Question 1. Today's date is 16.

पञ्चदशदिनाङ्कः कदा ? - Pañcadaśadināṅkaḥ kadā ? 
English Translation: When is the 15th?

पञ्चदशदिनाङ्कः ह्यः | - Pañcadaśadināṅkaḥ hyaḥ |
English Translation: The 15th was yesterday.

2. अद्य सोमवासरः |
2. Adya somavāsaraḥ |
English Translation: 2. Today is Monday.

मङ्गलवासरः कदा ? - Maṅgalavāsaraḥ kadā ?
English Translation: When is Tuesday?

3. अद्य २४ तमदिनाङ्कः |
3. Adya 24 tamadināṅkaḥ |
English Translation: 3. Today's date is 24.

२६ तमदिनाङ्कः कदा ? - 26 tamadināṅkaḥ kadā ?
English Translation: When is the 26th?