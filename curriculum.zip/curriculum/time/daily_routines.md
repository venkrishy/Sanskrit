कदा ? Kadā ?

एतेषां प्रश्नानां उत्तरं लिखतु - Eteṣāṁ praśnānām uttaraṁ likhatu.
Translation: Write the answers to these questions.

भवान् कदा उत्तिष्ठति ? - Bhavān kadā uttiṣṭhati ?
अहं पञ्चवादने उत्तिष्ठामि । - Ahaṁ pañcavādane uttiṣṭhāmi.
Translation: When do you wake up? - I wake up at 5 o'clock.

भवान् कदा विद्यालयं गच्छति ? - Bhavān kadā vidyālayaṁ gacchati?
Translation: When do you go to school?

सूर्योदयः कदा भवति ? - Sūryodayaḥ kadā bhavati ?
Translation: When does sunrise happen?

भवती कदा क्रीडति ? - Bhavatī kadā krīḍati ?
Translation: When do you (feminine) play?

भवती कदा पठति ? - Bhavatī kadā paṭhati ?
Translation: When do you (feminine) study?

एतेषाम् उत्तराणां प्रश्नं लिखतु - Eteṣām uttarāṇāṁ praśnaṁ likhatu.
Translation: Write the questions for these answers.

सीता सायंकाले नृत्याभ्यासं करोति । - Sītā sāyaṁkāle nṛtyābhyāsaṁ karoti.
Translation: Sita practices dance in the evening.

वेङ्कटेशः षड्वादने योगासनं करोति । - Veṅkaṭeśaḥ ṣaḍvādane yogāsanaṁ karoti.
Translation: Venkatesan does yoga at 6 o'clock. 

माता दशवादने पाकं करोति । - Mātā daśavādane pākaṁ karoti.
Translation: Mother cooks at 10 o'clock.

सा प्रातःकाले पूजां करोति । - Sā prātaḥkāle pūjāṁ karoti.
Translation: She does puja in the morning.

अहं मध्याह्ने भोजनं करोमि । - Ahaṁ madhyāhne bhojanaṁ karomi.
Translation: I have lunch at noon.